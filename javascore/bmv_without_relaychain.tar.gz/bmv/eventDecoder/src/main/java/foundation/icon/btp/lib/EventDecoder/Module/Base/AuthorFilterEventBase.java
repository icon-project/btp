package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AuthorFilterEventBase {
    public static byte[] eligibleUpdated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Percent(input, size);
       return input.take(size);
    }

}
