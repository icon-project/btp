package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class IdentityEventBase {
    public static byte[] identitySet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] identityCleared(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] identityKilled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] judgementRequested(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.RegistrarIndex(input, size);
       return input.take(size);
    }

    public static byte[] judgementUnrequested(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.RegistrarIndex(input, size);
       return input.take(size);
    }

    public static byte[] judgementGiven(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.RegistrarIndex(input, size);
       return input.take(size);
    }

    public static byte[] registrarAdded(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RegistrarIndex(input, size);
       return input.take(size);
    }

    public static byte[] subIdentityAdded(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] subIdentityRemoved(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] subIdentityRevoked(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

}
