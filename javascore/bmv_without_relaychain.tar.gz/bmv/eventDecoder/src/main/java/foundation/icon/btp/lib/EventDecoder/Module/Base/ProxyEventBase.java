package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class ProxyEventBase {
    public static byte[] proxyExecuted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

    public static byte[] anonymousCreated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.ProxyType(input, size);
       size += SizeDecoder.u16(input, size);
       return input.take(size);
    }

    public static byte[] announced(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

}
