package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class SudoEventBase {
    public static byte[] sudid(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

    public static byte[] keyChanged(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] sudoAsDone(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

}
