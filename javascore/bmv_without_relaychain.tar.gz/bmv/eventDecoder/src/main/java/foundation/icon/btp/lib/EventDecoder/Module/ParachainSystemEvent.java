package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class ParachainSystemEvent extends ParachainSystemEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return validationFunctionStored(input);
            case (byte)(1):
                return validationFunctionApplied(input);
            case (byte)(2):
                return upgradeAuthorized(input);
            case (byte)(3):
                return downwardMessagesReceived(input);
            case (byte)(4):
                return downwardMessagesProcessed(input);
        }
        return null;
    }
}
