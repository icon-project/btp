package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AssetsEvent extends AssetsEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return created(input);
            case (byte)(1):
                return issued(input);
            case (byte)(2):
                return transferred(input);
            case (byte)(3):
                return burned(input);
            case (byte)(4):
                return teamChanged(input);
            case (byte)(5):
                return ownerChanged(input);
            case (byte)(6):
                return frozen(input);
            case (byte)(7):
                return thawed(input);
            case (byte)(8):
                return assetFrozen(input);
            case (byte)(9):
                return assetThawed(input);
            case (byte)(10):
                return destroyed(input);
            case (byte)(11):
                return forceCreated(input);
            case (byte)(12):
                return metadataSet(input);
            case (byte)(13):
                return metadataCleared(input);
            case (byte)(14):
                return approvedTransfer(input);
            case (byte)(15):
                return approvalCancelled(input);
            case (byte)(16):
                return transferredApproved(input);
            case (byte)(17):
                return assetStatusChanged(input);
        }
        return null;
    }
}
