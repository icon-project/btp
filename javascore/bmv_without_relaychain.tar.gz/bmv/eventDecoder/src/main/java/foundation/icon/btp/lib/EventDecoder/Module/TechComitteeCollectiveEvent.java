package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class TechComitteeCollectiveEvent extends TechComitteeCollectiveEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return proposed(input);
            case (byte)(1):
                return voted(input);
            case (byte)(2):
                return approved(input);
            case (byte)(3):
                return disapproved(input);
            case (byte)(4):
                return executed(input);
            case (byte)(5):
                return memberExecuted(input);
            case (byte)(6):
                return closed(input);
        }
        return null;
    }
}
