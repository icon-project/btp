package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class CumulusXcmEventBase {
    public static byte[] invalidFormat(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder._u8_8_(input, size);
       return input.take(size);
    }

    public static byte[] unsupportedVersion(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder._u8_8_(input, size);
       return input.take(size);
    }

    public static byte[] executedDownward(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder._u8_8_(input, size);
       size += SizeDecoder.Outcome(input, size);
       return input.take(size);
    }

}
