package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class EVMEventBase {
    public static byte[] log(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.EvmLog(input, size);
       return input.take(size);
    }

    public static byte[] created(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.H160(input, size);
       return input.take(size);
    }

    public static byte[] createdFailed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.H160(input, size);
       return input.take(size);
    }

    public static byte[] executed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.H160(input, size);
       return input.take(size);
    }

    public static byte[] executedFailed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.H160(input, size);
       return input.take(size);
    }

    public static byte[] balanceDeposit(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.H160(input, size);
       size += SizeDecoder.U256(input, size);
       return input.take(size);
    }

    public static byte[] balanceWithdraw(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.H160(input, size);
       size += SizeDecoder.U256(input, size);
       return input.take(size);
    }

}
