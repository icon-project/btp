package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class SchedulerEvent extends SchedulerEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return scheduled(input);
            case (byte)(1):
                return canceled(input);
            case (byte)(2):
                return dispatched(input);
        }
        return null;
    }
}
