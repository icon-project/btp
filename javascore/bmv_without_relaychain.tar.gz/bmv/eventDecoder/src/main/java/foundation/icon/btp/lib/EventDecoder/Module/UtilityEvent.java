package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class UtilityEvent extends UtilityEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return batchInterrupted(input);
            case (byte)(1):
                return batchCompleted(input);
        }
        return null;
    }
}
