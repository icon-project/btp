package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class ProxyEvent extends ProxyEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return proxyExecuted(input);
            case (byte)(1):
                return anonymousCreated(input);
            case (byte)(2):
                return announced(input);
        }
        return null;
    }
}
