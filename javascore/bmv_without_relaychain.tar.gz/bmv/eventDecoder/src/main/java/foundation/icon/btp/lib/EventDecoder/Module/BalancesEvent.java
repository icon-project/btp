package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class BalancesEvent extends BalancesEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return endowed(input);
            case (byte)(1):
                return dustLost(input);
            case (byte)(2):
                return transfer(input);
            case (byte)(3):
                return balanceSet(input);
            case (byte)(4):
                return deposit(input);
            case (byte)(5):
                return reserved(input);
            case (byte)(6):
                return unreserved(input);
            case (byte)(7):
                return reserveRepatriated(input);
        }
        return null;
    }
}
