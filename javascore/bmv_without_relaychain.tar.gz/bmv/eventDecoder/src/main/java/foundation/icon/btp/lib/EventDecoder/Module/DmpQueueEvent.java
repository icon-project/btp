package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class DmpQueueEvent extends DmpQueueEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return invalidFormat(input);
            case (byte)(1):
                return unsupportedVersion(input);
            case (byte)(2):
                return executedDownward(input);
            case (byte)(3):
                return weightExhausted(input);
            case (byte)(4):
                return overweightEnqueued(input);
            case (byte)(5):
                return overweightServiced(input);
        }
        return null;
    }
}
