package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class MaintenanceModeEvent extends MaintenanceModeEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return enteredMaintenanceMode(input);
            case (byte)(1):
                return normalOperationResumed(input);
        }
        return null;
    }
}
