package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class EVMEvent extends EVMEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return log(input);
            case (byte)(1):
                return created(input);
            case (byte)(2):
                return createdFailed(input);
            case (byte)(3):
                return executed(input);
            case (byte)(4):
                return executedFailed(input);
            case (byte)(5):
                return balanceDeposit(input);
            case (byte)(6):
                return balanceWithdraw(input);
        }
        return null;
    }
}
