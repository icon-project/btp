package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class TreasuryEventBase {
    public static byte[] proposed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ProposalIndex(input, size);
       return input.take(size);
    }

    public static byte[] spending(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] awarded(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ProposalIndex(input, size);
       size += SizeDecoder.Balance(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] rejected(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ProposalIndex(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] burnt(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] rollover(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] deposit(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

}
