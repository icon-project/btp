package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class SystemEvent extends SystemEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return extrinsicSuccess(input);
            case (byte)(1):
                return extrinsicFailed(input);
            case (byte)(2):
                return codeUpdated(input);
            case (byte)(3):
                return newAccount(input);
            case (byte)(4):
                return killedAccount(input);
            case (byte)(5):
                return remarked(input);
        }
        return null;
    }
}
