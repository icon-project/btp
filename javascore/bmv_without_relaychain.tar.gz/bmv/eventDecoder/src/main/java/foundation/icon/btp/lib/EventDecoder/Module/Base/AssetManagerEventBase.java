package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AssetManagerEventBase {
    public static byte[] assetRegistered(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AssetType(input, size);
       size += SizeDecoder.AssetRegistrarMetadata(input, size);
       return input.take(size);
    }

    public static byte[] unitsPerSecondChanged(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.u128(input, size);
       return input.take(size);
    }

}
