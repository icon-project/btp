package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AuthorMappingEventBase {
    public static byte[] authorRegistered(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AuthorId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] authorDeRegistered(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AuthorId(input, size);
       return input.take(size);
    }

    public static byte[] authorRotated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AuthorId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] defunctAuthorBusted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AuthorId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

}
