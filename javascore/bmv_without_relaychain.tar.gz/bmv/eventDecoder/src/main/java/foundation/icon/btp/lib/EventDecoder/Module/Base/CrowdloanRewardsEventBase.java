package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class CrowdloanRewardsEventBase {
    public static byte[] initialPaymentMade(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] nativeIdentityAssociated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RelayChainAccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] rewardsPaid(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] rewardAddressUpdated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] initializedAlreadyInitializedAccount(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RelayChainAccountId(input, size);
       size += SizeDecoder.Option_AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] initializedAccountWithNotEnoughContribution(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RelayChainAccountId(input, size);
       size += SizeDecoder.Option_AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

}
