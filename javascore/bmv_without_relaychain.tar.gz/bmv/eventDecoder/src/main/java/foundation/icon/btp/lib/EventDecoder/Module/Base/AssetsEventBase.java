package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AssetsEventBase {
    public static byte[] created(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] issued(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.TAssetBalance(input, size);
       return input.take(size);
    }

    public static byte[] transferred(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.TAssetBalance(input, size);
       return input.take(size);
    }

    public static byte[] burned(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.TAssetBalance(input, size);
       return input.take(size);
    }

    public static byte[] teamChanged(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] ownerChanged(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] frozen(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] thawed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] assetFrozen(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       return input.take(size);
    }

    public static byte[] assetThawed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       return input.take(size);
    }

    public static byte[] destroyed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       return input.take(size);
    }

    public static byte[] forceCreated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] metadataSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.Bytes(input, size);
       size += SizeDecoder.Bytes(input, size);
       size += SizeDecoder.u8(input, size);
       size += SizeDecoder.bool(input, size);
       return input.take(size);
    }

    public static byte[] metadataCleared(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       return input.take(size);
    }

    public static byte[] approvedTransfer(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.TAssetBalance(input, size);
       return input.take(size);
    }

    public static byte[] approvalCancelled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] transferredApproved(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.TAssetBalance(input, size);
       return input.take(size);
    }

    public static byte[] assetStatusChanged(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AssetId(input, size);
       return input.take(size);
    }

}
