package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class SudoEvent extends SudoEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return sudid(input);
            case (byte)(1):
                return keyChanged(input);
            case (byte)(2):
                return sudoAsDone(input);
        }
        return null;
    }
}
