package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class PolkadotXcmEvent extends PolkadotXcmEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return attempted(input);
            case (byte)(1):
                return sent(input);
        }
        return null;
    }
}
