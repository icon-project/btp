package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class BalancesEventBase {
    public static byte[] endowed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] dustLost(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] transfer(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] balanceSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] deposit(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] reserved(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] unreserved(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] reserveRepatriated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       size += SizeDecoder.BalanceStatus(input, size);
       return input.take(size);
    }

}
