package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class ParachainSystemEventBase {
    public static byte[] validationFunctionStored(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RelayChainBlockNumber(input, size);
       return input.take(size);
    }

    public static byte[] validationFunctionApplied(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RelayChainBlockNumber(input, size);
       return input.take(size);
    }

    public static byte[] upgradeAuthorized(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

    public static byte[] downwardMessagesReceived(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.u32(input, size);
       return input.take(size);
    }

    public static byte[] downwardMessagesProcessed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Weight(input, size);
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

}
