package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class DemocracyEventBase {
    public static byte[] proposed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.PropIndex(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] tabled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.PropIndex(input, size);
       size += SizeDecoder.Balance(input, size);
       size += SizeDecoder.Vec_AccountId(input, size);
       return input.take(size);
    }

    public static byte[] externalTabled(ByteSliceInput input) {
       return null;
    }

    public static byte[] started(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ReferendumIndex(input, size);
       size += SizeDecoder.VoteThreshold(input, size);
       return input.take(size);
    }

    public static byte[] passed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ReferendumIndex(input, size);
       return input.take(size);
    }

    public static byte[] notPassed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ReferendumIndex(input, size);
       return input.take(size);
    }

    public static byte[] cancelled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ReferendumIndex(input, size);
       return input.take(size);
    }

    public static byte[] executed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.ReferendumIndex(input, size);
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

    public static byte[] delegated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] undelegated(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] vetoed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.BlockNumber(input, size);
       return input.take(size);
    }

    public static byte[] preimageNoted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] preimageUsed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       return input.take(size);
    }

    public static byte[] preimageInvalid(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.ReferendumIndex(input, size);
       return input.take(size);
    }

    public static byte[] preimageMissing(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.ReferendumIndex(input, size);
       return input.take(size);
    }

    public static byte[] preimageReaped(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Balance(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] blacklisted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

}
