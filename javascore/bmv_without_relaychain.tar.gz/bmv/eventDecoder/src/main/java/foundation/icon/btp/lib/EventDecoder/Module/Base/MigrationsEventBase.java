package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class MigrationsEventBase {
    public static byte[] runtimeUpgradeStarted(ByteSliceInput input) {
       return null;
    }

    public static byte[] runtimeUpgradeCompleted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Weight(input, size);
       return input.take(size);
    }

    public static byte[] migrationStarted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Bytes(input, size);
       return input.take(size);
    }

    public static byte[] migrationCompleted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Bytes(input, size);
       size += SizeDecoder.Weight(input, size);
       return input.take(size);
    }

}
