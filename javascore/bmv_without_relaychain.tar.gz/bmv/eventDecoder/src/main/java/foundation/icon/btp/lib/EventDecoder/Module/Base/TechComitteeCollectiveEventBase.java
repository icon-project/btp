package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class TechComitteeCollectiveEventBase {
    public static byte[] proposed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.ProposalIndex(input, size);
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.MemberCount(input, size);
       return input.take(size);
    }

    public static byte[] voted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.bool(input, size);
       size += SizeDecoder.MemberCount(input, size);
       size += SizeDecoder.MemberCount(input, size);
       return input.take(size);
    }

    public static byte[] approved(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

    public static byte[] disapproved(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

    public static byte[] executed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

    public static byte[] memberExecuted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

    public static byte[] closed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Hash(input, size);
       size += SizeDecoder.MemberCount(input, size);
       size += SizeDecoder.MemberCount(input, size);
       return input.take(size);
    }

}
