package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class DemocracyEvent extends DemocracyEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return proposed(input);
            case (byte)(1):
                return tabled(input);
            case (byte)(2):
                return externalTabled(input);
            case (byte)(3):
                return started(input);
            case (byte)(4):
                return passed(input);
            case (byte)(5):
                return notPassed(input);
            case (byte)(6):
                return cancelled(input);
            case (byte)(7):
                return executed(input);
            case (byte)(8):
                return delegated(input);
            case (byte)(9):
                return undelegated(input);
            case (byte)(10):
                return vetoed(input);
            case (byte)(11):
                return preimageNoted(input);
            case (byte)(12):
                return preimageUsed(input);
            case (byte)(13):
                return preimageInvalid(input);
            case (byte)(14):
                return preimageMissing(input);
            case (byte)(15):
                return preimageReaped(input);
            case (byte)(16):
                return blacklisted(input);
        }
        return null;
    }
}
