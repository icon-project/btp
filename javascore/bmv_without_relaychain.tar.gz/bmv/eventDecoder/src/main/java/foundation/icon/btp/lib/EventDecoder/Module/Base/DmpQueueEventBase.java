package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class DmpQueueEventBase {
    public static byte[] invalidFormat(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.MessageId(input, size);
       return input.take(size);
    }

    public static byte[] unsupportedVersion(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.MessageId(input, size);
       return input.take(size);
    }

    public static byte[] executedDownward(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.MessageId(input, size);
       size += SizeDecoder.Outcome(input, size);
       return input.take(size);
    }

    public static byte[] weightExhausted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.MessageId(input, size);
       size += SizeDecoder.Weight(input, size);
       size += SizeDecoder.Weight(input, size);
       return input.take(size);
    }

    public static byte[] overweightEnqueued(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.MessageId(input, size);
       size += SizeDecoder.OverweightIndex(input, size);
       size += SizeDecoder.Weight(input, size);
       return input.take(size);
    }

    public static byte[] overweightServiced(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.OverweightIndex(input, size);
       size += SizeDecoder.Weight(input, size);
       return input.take(size);
    }

}
