package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class XTokensEvent extends XTokensEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return transferred(input);
            case (byte)(1):
                return transferredMultiAsset(input);
        }
        return null;
    }
}
