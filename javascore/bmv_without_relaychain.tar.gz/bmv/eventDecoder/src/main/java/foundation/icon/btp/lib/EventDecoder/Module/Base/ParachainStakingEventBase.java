package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class ParachainStakingEventBase {
    public static byte[] newRound(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.BlockNumber(input, size);
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.u32(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] joinedCollatorCandidates(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] collatorChosen(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] collatorBondedMore(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] collatorBondedLess(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] collatorWentOffline(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] collatorBackOnline(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] collatorScheduledExit(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.RoundIndex(input, size);
       return input.take(size);
    }

    public static byte[] collatorLeft(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] nominationIncreased(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.bool(input, size);
       return input.take(size);
    }

    public static byte[] nominationDecreased(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.bool(input, size);
       return input.take(size);
    }

    public static byte[] nominatorExitScheduled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.RoundIndex(input, size);
       return input.take(size);
    }

    public static byte[] nominationRevocationScheduled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.RoundIndex(input, size);
       return input.take(size);
    }

    public static byte[] nominatorLeft(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] nomination(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.NominatorAdded(input, size);
       return input.take(size);
    }

    public static byte[] nominatorLeftCollator(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] rewarded(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] reservedForParachainBond(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] parachainBondAccountSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] parachainBondReservePercentSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Percent(input, size);
       size += SizeDecoder.Percent(input, size);
       return input.take(size);
    }

    public static byte[] inflationSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       return input.take(size);
    }

    public static byte[] stakeExpectationsSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       size += SizeDecoder.BalanceOf(input, size);
       return input.take(size);
    }

    public static byte[] totalSelectedSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.u32(input, size);
       size += SizeDecoder.u32(input, size);
       return input.take(size);
    }

    public static byte[] collatorCommissionSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       return input.take(size);
    }

    public static byte[] blocksPerRoundSet(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.RoundIndex(input, size);
       size += SizeDecoder.BlockNumber(input, size);
       size += SizeDecoder.u32(input, size);
       size += SizeDecoder.u32(input, size);
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       size += SizeDecoder.Perbill(input, size);
       return input.take(size);
    }

}
