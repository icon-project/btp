package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class SystemEventBase {
    public static byte[] extrinsicSuccess(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.DispatchInfo(input, size);
       return input.take(size);
    }

    public static byte[] extrinsicFailed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.DispatchError(input, size);
       size += SizeDecoder.DispatchInfo(input, size);
       return input.take(size);
    }

    public static byte[] codeUpdated(ByteSliceInput input) {
       return null;
    }

    public static byte[] newAccount(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] killedAccount(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       return input.take(size);
    }

    public static byte[] remarked(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.Hash(input, size);
       return input.take(size);
    }

}
