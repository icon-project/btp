package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class TreasuryEvent extends TreasuryEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return proposed(input);
            case (byte)(1):
                return spending(input);
            case (byte)(2):
                return awarded(input);
            case (byte)(3):
                return rejected(input);
            case (byte)(4):
                return burnt(input);
            case (byte)(5):
                return rollover(input);
            case (byte)(6):
                return deposit(input);
        }
        return null;
    }
}
