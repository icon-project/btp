package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class MigrationsEvent extends MigrationsEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return runtimeUpgradeStarted(input);
            case (byte)(1):
                return runtimeUpgradeCompleted(input);
            case (byte)(2):
                return migrationStarted(input);
            case (byte)(3):
                return migrationCompleted(input);
        }
        return null;
    }
}
