package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class PolkadotXcmEventBase {
    public static byte[] attempted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Outcome(input, size);
       return input.take(size);
    }

    public static byte[] sent(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.MultiLocation(input, size);
       size += SizeDecoder.MultiLocation(input, size);
       size += SizeDecoder.Xcm(input, size);
       return input.take(size);
    }

}
