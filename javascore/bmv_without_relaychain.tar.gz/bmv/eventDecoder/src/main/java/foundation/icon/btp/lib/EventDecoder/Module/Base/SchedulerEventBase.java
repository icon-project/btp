package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class SchedulerEventBase {
    public static byte[] scheduled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.BlockNumber(input, size);
       size += SizeDecoder.u32(input, size);
       return input.take(size);
    }

    public static byte[] canceled(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.BlockNumber(input, size);
       size += SizeDecoder.u32(input, size);
       return input.take(size);
    }

    public static byte[] dispatched(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.TaskAddress(input, size);
       size += SizeDecoder.Option_Bytes(input, size);
       size += SizeDecoder.DispatchResult(input, size);
       return input.take(size);
    }

}
