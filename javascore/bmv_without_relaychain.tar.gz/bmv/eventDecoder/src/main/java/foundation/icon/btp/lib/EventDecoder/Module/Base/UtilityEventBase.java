package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class UtilityEventBase {
    public static byte[] batchInterrupted(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.u32(input, size);
       size += SizeDecoder.DispatchError(input, size);
       return input.take(size);
    }

    public static byte[] batchCompleted(ByteSliceInput input) {
       return null;
    }

}
