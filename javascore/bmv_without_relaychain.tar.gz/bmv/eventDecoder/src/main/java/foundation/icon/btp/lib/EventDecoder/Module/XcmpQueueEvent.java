package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class XcmpQueueEvent extends XcmpQueueEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return success(input);
            case (byte)(1):
                return fail(input);
            case (byte)(2):
                return badVersion(input);
            case (byte)(3):
                return badFormat(input);
            case (byte)(4):
                return upwardMessageSent(input);
            case (byte)(5):
                return xcmpMessageSent(input);
        }
        return null;
    }
}
