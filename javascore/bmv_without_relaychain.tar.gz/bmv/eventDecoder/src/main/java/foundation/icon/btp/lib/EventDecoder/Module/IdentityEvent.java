package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class IdentityEvent extends IdentityEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return identitySet(input);
            case (byte)(1):
                return identityCleared(input);
            case (byte)(2):
                return identityKilled(input);
            case (byte)(3):
                return judgementRequested(input);
            case (byte)(4):
                return judgementUnrequested(input);
            case (byte)(5):
                return judgementGiven(input);
            case (byte)(6):
                return registrarAdded(input);
            case (byte)(7):
                return subIdentityAdded(input);
            case (byte)(8):
                return subIdentityRemoved(input);
            case (byte)(9):
                return subIdentityRevoked(input);
        }
        return null;
    }
}
