package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class XcmpQueueEventBase {
    public static byte[] success(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Option_Hash(input, size);
       return input.take(size);
    }

    public static byte[] fail(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Option_Hash(input, size);
       size += SizeDecoder.XcmError(input, size);
       return input.take(size);
    }

    public static byte[] badVersion(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Option_Hash(input, size);
       return input.take(size);
    }

    public static byte[] badFormat(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Option_Hash(input, size);
       return input.take(size);
    }

    public static byte[] upwardMessageSent(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Option_Hash(input, size);
       return input.take(size);
    }

    public static byte[] xcmpMessageSent(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.Option_Hash(input, size);
       return input.take(size);
    }

}
