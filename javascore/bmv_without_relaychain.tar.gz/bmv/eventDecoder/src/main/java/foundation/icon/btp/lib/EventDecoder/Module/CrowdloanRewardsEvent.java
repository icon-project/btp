package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class CrowdloanRewardsEvent extends CrowdloanRewardsEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return initialPaymentMade(input);
            case (byte)(1):
                return nativeIdentityAssociated(input);
            case (byte)(2):
                return rewardsPaid(input);
            case (byte)(3):
                return rewardAddressUpdated(input);
            case (byte)(4):
                return initializedAlreadyInitializedAccount(input);
            case (byte)(5):
                return initializedAccountWithNotEnoughContribution(input);
        }
        return null;
    }
}
