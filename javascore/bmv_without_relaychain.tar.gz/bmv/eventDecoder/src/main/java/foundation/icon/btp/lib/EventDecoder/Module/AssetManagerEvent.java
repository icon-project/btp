package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AssetManagerEvent extends AssetManagerEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return assetRegistered(input);
            case (byte)(1):
                return unitsPerSecondChanged(input);
        }
        return null;
    }
}
