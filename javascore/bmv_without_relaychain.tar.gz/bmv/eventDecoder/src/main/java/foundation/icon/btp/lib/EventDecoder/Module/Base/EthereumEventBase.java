package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class EthereumEventBase {
    public static byte[] executed(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.H160(input, size);
       size += SizeDecoder.H160(input, size);
       size += SizeDecoder.H256(input, size);
       size += SizeDecoder.ExitReason(input, size);
       return input.take(size);
    }

}
