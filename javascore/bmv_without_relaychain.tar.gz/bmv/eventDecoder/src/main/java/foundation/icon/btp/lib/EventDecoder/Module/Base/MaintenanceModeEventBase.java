package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class MaintenanceModeEventBase {
    public static byte[] enteredMaintenanceMode(ByteSliceInput input) {
       return null;
    }

    public static byte[] normalOperationResumed(ByteSliceInput input) {
       return null;
    }

}
