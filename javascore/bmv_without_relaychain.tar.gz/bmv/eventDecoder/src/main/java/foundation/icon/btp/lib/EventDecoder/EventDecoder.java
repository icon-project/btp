package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class EventDecoder extends EventDecoderBase {
    public static byte[] decodeEvent(byte mainIndex, byte subIndex, ByteSliceInput input) {
        SizeDecoder.accountIdSize = 20;
        switch (mainIndex) {
           case (byte)(0):
                return SystemEvent.decodeEvent(subIndex, input);
           case (byte)(1):
                return ParachainSystemEvent.decodeEvent(subIndex, input);
           case (byte)(10):
                return BalancesEvent.decodeEvent(subIndex, input);
           case (byte)(20):
                return ParachainStakingEvent.decodeEvent(subIndex, input);
           case (byte)(22):
                return AuthorFilterEvent.decodeEvent(subIndex, input);
           case (byte)(23):
                return AuthorMappingEvent.decodeEvent(subIndex, input);
           case (byte)(30):
                return UtilityEvent.decodeEvent(subIndex, input);
           case (byte)(31):
                return ProxyEvent.decodeEvent(subIndex, input);
           case (byte)(32):
                return MaintenanceModeEvent.decodeEvent(subIndex, input);
           case (byte)(33):
                return IdentityEvent.decodeEvent(subIndex, input);
           case (byte)(34):
                return MigrationsEvent.decodeEvent(subIndex, input);
           case (byte)(51):
                return EVMEvent.decodeEvent(subIndex, input);
           case (byte)(52):
                return EthereumEvent.decodeEvent(subIndex, input);
           case (byte)(60):
                return SchedulerEvent.decodeEvent(subIndex, input);
           case (byte)(61):
                return DemocracyEvent.decodeEvent(subIndex, input);
           case (byte)(70):
                return CouncilCollectiveEvent.decodeEvent(subIndex, input);
           case (byte)(71):
                return TechComitteeCollectiveEvent.decodeEvent(subIndex, input);
           case (byte)(80):
                return TreasuryEvent.decodeEvent(subIndex, input);
           case (byte)(90):
                return CrowdloanRewardsEvent.decodeEvent(subIndex, input);
        }
        return null;
    }
}
