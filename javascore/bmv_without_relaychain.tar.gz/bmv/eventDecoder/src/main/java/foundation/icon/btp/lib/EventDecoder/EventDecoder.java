package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class EventDecoder extends EventDecoderBase {
    public static byte[] decodeEvent(byte mainIndex, byte subIndex, ByteSliceInput input) {
        SizeDecoder.accountIdSize = 20;
        switch (mainIndex) {
           case (byte)(0):
                return SystemEvent.decodeEvent(subIndex, input);
           case (byte)(1):
                return UtilityEvent.decodeEvent(subIndex, input);
           case (byte)(3):
                return BalancesEvent.decodeEvent(subIndex, input);
           case (byte)(4):
                return SudoEvent.decodeEvent(subIndex, input);
           case (byte)(6):
                return ParachainSystemEvent.decodeEvent(subIndex, input);
           case (byte)(10):
                return EVMEvent.decodeEvent(subIndex, input);
           case (byte)(11):
                return EthereumEvent.decodeEvent(subIndex, input);
           case (byte)(12):
                return ParachainStakingEvent.decodeEvent(subIndex, input);
           case (byte)(13):
                return SchedulerEvent.decodeEvent(subIndex, input);
           case (byte)(14):
                return DemocracyEvent.decodeEvent(subIndex, input);
           case (byte)(15):
                return CouncilCollectiveEvent.decodeEvent(subIndex, input);
           case (byte)(16):
                return TechComitteeCollectiveEvent.decodeEvent(subIndex, input);
           case (byte)(17):
                return TreasuryEvent.decodeEvent(subIndex, input);
           case (byte)(19):
                return AuthorFilterEvent.decodeEvent(subIndex, input);
           case (byte)(20):
                return CrowdloanRewardsEvent.decodeEvent(subIndex, input);
           case (byte)(21):
                return AuthorMappingEvent.decodeEvent(subIndex, input);
           case (byte)(22):
                return ProxyEvent.decodeEvent(subIndex, input);
           case (byte)(23):
                return MaintenanceModeEvent.decodeEvent(subIndex, input);
           case (byte)(24):
                return IdentityEvent.decodeEvent(subIndex, input);
           case (byte)(25):
                return XcmpQueueEvent.decodeEvent(subIndex, input);
           case (byte)(26):
                return CumulusXcmEvent.decodeEvent(subIndex, input);
           case (byte)(27):
                return DmpQueueEvent.decodeEvent(subIndex, input);
           case (byte)(28):
                return PolkadotXcmEvent.decodeEvent(subIndex, input);
           case (byte)(29):
                return AssetsEvent.decodeEvent(subIndex, input);
           case (byte)(30):
                return XTokensEvent.decodeEvent(subIndex, input);
           case (byte)(31):
                return AssetManagerEvent.decodeEvent(subIndex, input);
           case (byte)(32):
                return MigrationsEvent.decodeEvent(subIndex, input);
        }
        return null;
    }
}
