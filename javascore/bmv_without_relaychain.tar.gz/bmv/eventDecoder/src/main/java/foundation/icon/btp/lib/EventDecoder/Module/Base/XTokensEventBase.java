package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class XTokensEventBase {
    public static byte[] transferred(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.CurrencyId(input, size);
       size += SizeDecoder.Balance(input, size);
       size += SizeDecoder.MultiLocation(input, size);
       return input.take(size);
    }

    public static byte[] transferredMultiAsset(ByteSliceInput input) {
       int size = 0;
       size += SizeDecoder.AccountId(input, size);
       size += SizeDecoder.MultiAsset(input, size);
       size += SizeDecoder.MultiLocation(input, size);
       return input.take(size);
    }

}
