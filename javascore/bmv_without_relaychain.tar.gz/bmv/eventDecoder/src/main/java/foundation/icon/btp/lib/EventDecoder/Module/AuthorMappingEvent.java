package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class AuthorMappingEvent extends AuthorMappingEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return authorRegistered(input);
            case (byte)(1):
                return authorDeRegistered(input);
            case (byte)(2):
                return authorRotated(input);
            case (byte)(3):
                return defunctAuthorBusted(input);
        }
        return null;
    }
}
