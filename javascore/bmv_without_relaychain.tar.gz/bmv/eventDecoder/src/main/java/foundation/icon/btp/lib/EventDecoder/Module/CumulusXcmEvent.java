package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class CumulusXcmEvent extends CumulusXcmEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return invalidFormat(input);
            case (byte)(1):
                return unsupportedVersion(input);
            case (byte)(2):
                return executedDownward(input);
        }
        return null;
    }
}
