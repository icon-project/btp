package foundation.icon.btp.lib.EventDecoder;

import foundation.icon.btp.lib.utils.ByteSliceInput;

public class ParachainStakingEvent extends ParachainStakingEventBase {
    public static byte[] decodeEvent(byte subIndex, ByteSliceInput input) {
        switch (subIndex) {
            case (byte)(0):
                return newRound(input);
            case (byte)(1):
                return joinedCollatorCandidates(input);
            case (byte)(2):
                return collatorChosen(input);
            case (byte)(3):
                return collatorBondedMore(input);
            case (byte)(4):
                return collatorBondedLess(input);
            case (byte)(5):
                return collatorWentOffline(input);
            case (byte)(6):
                return collatorBackOnline(input);
            case (byte)(7):
                return collatorScheduledExit(input);
            case (byte)(8):
                return collatorLeft(input);
            case (byte)(9):
                return nominationIncreased(input);
            case (byte)(10):
                return nominationDecreased(input);
            case (byte)(11):
                return nominatorExitScheduled(input);
            case (byte)(12):
                return nominationRevocationScheduled(input);
            case (byte)(13):
                return nominatorLeft(input);
            case (byte)(14):
                return nomination(input);
            case (byte)(15):
                return nominatorLeftCollator(input);
            case (byte)(16):
                return rewarded(input);
            case (byte)(17):
                return reservedForParachainBond(input);
            case (byte)(18):
                return parachainBondAccountSet(input);
            case (byte)(19):
                return parachainBondReservePercentSet(input);
            case (byte)(20):
                return inflationSet(input);
            case (byte)(21):
                return stakeExpectationsSet(input);
            case (byte)(22):
                return totalSelectedSet(input);
            case (byte)(23):
                return collatorCommissionSet(input);
            case (byte)(24):
                return blocksPerRoundSet(input);
        }
        return null;
    }
}
