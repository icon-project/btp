package foundation.icon.btp.lib.mta;
public class MTAStatus {
    public long height;
    public long offset;

    public MTAStatus(
        long height,
        long offset
    ) {
        this.height = height;
        this.offset = offset;
    }
}
