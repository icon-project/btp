#  Copyright 2020 ICON Foundation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from ..lib import BTPExceptionCode, BMCException


class BMCExceptionCode(BTPExceptionCode):
    UNAUTHORIZED = 1
    INVALID_SN = 2
    ALREADY_EXISTS_BMV = 3
    NOT_EXISTS_BMV = 4
    ALREADY_EXISTS_BSH = 5
    NOT_EXISTS_BSH = 6
    ALREADY_EXISTS_LINK = 7
    NOT_EXISTS_LINK = 8
    UNREACHABLE = 9
    NOT_EXISTS_PERMISSION = 10


class UnauthorizedException(BMCException):
    def __init__(self, message: str):
        super().__init__(message, BMCExceptionCode.UNAUTHORIZED)
